# AXIOM — Replit Implementation Handoff

**Source branch:** `arena/a942c4c1-axiom`  
**Current implementation commit:** `8c41bd2` (`feat: add safe configuration foundation`)  
**Specification commit:** `d828e91` (`docs: add AXIOM architecture and delivery specification`)  
**Prepared:** 2026-11-14 UTC

## What this pack is

This is the Arena-reviewed AXIOM architecture and engineering contract. Read in the order required by `AGENTS.md`. `MASTER_PROJECT_CONTEXT.md` is authoritative whenever it conflicts with another document.

## Current implementation boundary

Phase 1 / P1-T1 is complete on the source branch: safe JSON configuration, closed validation, redaction, structured logging, typed errors, a zero-dependency Node 22 project, and 17 passing unit/security tests. No Minecraft, Aternos, Discord, Ollama, hosted AI provider, dashboard, or SQLite integration has been implemented or exercised.

Do not duplicate or replace the P1-T1 modules. Reuse the existing branch if it is available. The next owned work packet is P1-T2 (`StateStore` and retention), but it remains subject to an actual Termux `node:sqlite` preflight.

## Non-negotiable gates

1. **Minecraft Java 26.2 is blocked / unverified.** Published Mineflayer, minecraft-protocol, and minecraft-data packages audited on 2026-11-14 support through 26.1. Do not patch node_modules, use a protocol proxy, or silently downgrade.
2. **Never connect to Aternos automatically.** No website automation, AFK/fake activity, idle-timeout evasion, player-limit evasion, or indefinite reconnect. Use `WAITING_FOR_OPERATOR` after unavailability.
3. **AI is advisory data only.** It cannot execute shell/JavaScript/raw packets/arbitrary methods or privileged commands.
4. **Minecraft chat is untrusted and cannot authorize work.** Only immutable configured Discord user IDs may issue privileged commands.
5. **No paid automatic provider calls.** Gemini/Groq stay disabled without explicit owner no-charge proof and budget configuration.
6. **Five configured identities are not five certified live clients.** Start with the persisted certified cap and measured hardware gates.

## Required Replit work style

- Use Node.js CommonJS, async/await, no unnecessary framework/dependency.
- Respect the non-overlapping task ownership in `docs/spec/IMPLEMENTATION_ROADMAP.md`.
- Keep `AXIOM-INTEGRATOR` ownership of package/lock/composition/migration ordering.
- Update specifications and contract tests when a public DTO/event changes.
- Mark real results `MEASURED`, harness results `SIMULATED`, and untested facts `UNKNOWN`; never fabricate a pass.

## Critical documents

- `MASTER_PROJECT_CONTEXT.md`
- `AGENTS.md`
- `docs/spec/MASTER_SPEC.md`
- `docs/spec/ARCHITECTURE.md`
- `docs/spec/MODULE_INTERFACES.md`
- `docs/spec/AI_PROTOCOL.md`
- `docs/spec/SECURITY_PLAN.md`
- `docs/spec/PERFORMANCE_PLAN.md`
- `docs/spec/TEST_PLAN.md`
- `docs/spec/ACCEPTANCE_CRITERIA.md`
- `docs/spec/IMPLEMENTATION_ROADMAP.md`
- `docs/DECISIONS.md`
