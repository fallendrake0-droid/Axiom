# AXIOM — Replit Implementation Handoff

**Source branch:** `arena/a942c4c1-axiom`  
**Foundation commit:** `8c41bd2` (`feat: add safe configuration foundation`)  
**Specification baseline:** `d828e91` plus the current branch documentation reconciliation  
**Prepared:** 2026-11-14 UTC

## Start here

Read `MASTER_PROJECT_CONTEXT.md`, then `AGENTS.md`, then the specification documents in the mandatory order. This pack is a reviewed architecture and task contract. `MASTER_PROJECT_CONTEXT.md` is authoritative if a document conflict is found.

## Existing implementation boundary

The GitHub branch already contains only the safe P1-T1 foundation: zero-dependency Node 22 setup, closed JSON configuration validation, secret redaction, structured logging, typed errors, and 17 unit/security tests. It has no Mineflayer, SQLite, Discord, dashboard, provider transport, Minecraft socket, Aternos operation, or device benchmark. Reuse that foundation; do not duplicate it.

The next task is P1-T2 (`StateStore` and retention) only after the Termux `node:sqlite` preflight. Do not progress to live Minecraft work without its separate compatibility and owner gates.

## Required Discord command contract

Implement exactly these slash commands through the shared Coordinator, never by direct database or Mineflayer access:

```text
/status  /bots  /bot  /task  /cancel  /stop  /say  /sayall  /provider  /chatmode  /help
```

`/cancel` must fence active leases through `TaskManager`; `/bot` returns a safe single-bot status snapshot; `/sayall` uses ChatManager throttling. All privileged commands require configured immutable Discord user IDs.

## Non-negotiable blockers and safety rules

1. **Minecraft Java 26.2 is blocked / unverified.** The audited published Mineflayer, minecraft-protocol, and minecraft-data tuple supports through 26.1. Do not patch node_modules, use a protocol proxy, or silently downgrade.
2. **Never automate Aternos or keep it online.** No website automation, AFK/fake activity, idle-timeout evasion, player-limit evasion, or indefinite reconnect. Use `WAITING_FOR_OPERATOR` after unavailability.
3. **AI is advisory data only.** It cannot execute shell/JavaScript/raw packets/arbitrary methods or privileged actions.
4. **Minecraft chat is untrusted and not administrative.** Only immutable configured Discord user IDs can issue privileged control commands.
5. **No automatic paid AI usage.** Gemini/Groq remain disabled without explicit owner no-charge approval, current quota review, and hard budgets.
6. **Five identities are not five certified live clients.** Keep the staged measured-cap gate.

## Integration rules

- Use Node.js CommonJS and async/await.
- Respect exact non-overlapping ownership in `docs/spec/IMPLEMENTATION_ROADMAP.md`.
- `AXIOM-INTEGRATOR` owns package/lockfile/composition/migration ordering.
- Update contracts and tests together when public DTOs/events change.
- Never label untested behavior as working. Use `MEASURED`, `SIMULATED`, `ESTIMATED`, and `UNKNOWN` correctly.
